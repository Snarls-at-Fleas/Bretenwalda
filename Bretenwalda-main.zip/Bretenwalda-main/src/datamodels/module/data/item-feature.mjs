import BretenwaldaItemBase from "./base-item.mjs";

export default class BretenwaldaFeature extends BretenwaldaItemBase {}